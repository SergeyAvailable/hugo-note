+++
author = "Hugo Authors"
date = "2019-03-04"
title = "Página Externa: Wiki Hugo Coder"
slug = "hugo-coder-wiki"
tags = [
    "hugo",
    "development",
    "themes"
]
categories = [
    "Development",
]
externalLink = "https://github.com/luizdepra/hugo-coder/wiki"
+++
